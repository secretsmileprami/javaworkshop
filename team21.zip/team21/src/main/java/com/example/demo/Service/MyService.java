package com.example.demo.Service;

import org.springframework.stereotype.Service;

@Service

public class MyService {
	
		public int add(int a, int  b) {
			System.out.println("a:"+a);
			System.out.println("b:"+b);
			return a+b;
		
		}
	}


