package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.MyService;

@RestController
public class HomeController {
	@Autowired
	MyService r;
	@GetMapping("/getUser")
	public String requestOne()
	{
		return "This is first Request";
	}
	@GetMapping("/getAuthor")
	public String requestTwo()
	{
		return "This is Author details";
	}
	@GetMapping("/add/{value1}/{value2}")
	public String requestThree(@PathVariable("value1") int value1,@PathVariable("value2") int value2) {
	int result= r.add(value1, value2);
	
		return "The Addition is: " +result;
	}
	@GetMapping("/validate/{uname}/{pwd}")
	public String login(@PathVariable("uname") String uname,@PathVariable("pwd") String pwd)
	{
		String o_uname="ramya";
	    String o_pwd="ramya123";
	    if((o_uname.equals(o_uname)&& o_pwd.equals(o_pwd))){
	    	return "welcome";
	    }
	    else {
	    	return "invalid username/pwd";
	    }
	}
}
